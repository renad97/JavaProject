package happymoment;

import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;

import java.io.*;
import java.net.URL;
import java.text.Format;
import java.util.ResourceBundle;

public class HappyMoment5 implements Initializable {
    public Label TotalPrice;
    public TextField txt1;
    public TextField txt2;
    public TextField txt3;
    public TextField txt4;
    public TextField txt5;
    public TextField txtTotl;


    @Override
    public void initialize(URL location, ResourceBundle resources) {

    }

    public void setOrder(int DisP, double giftTotl, String DiNAme){

        try {
            FileInputStream fis = new FileInputStream("GiftOrders.dat");
            ObjectInputStream ois = new ObjectInputStream(fis);

            Orders o = (Orders) ois.readObject();

            for (int i=0; i< o.getGiftName().size(); i++){
                if (i==0){
                    txt1.setText(o.getGiftName().get(i));
                }
                if (i==1){
                    txt2.setText(o.getGiftName().get(i));
                }
                if (i==2){
                    txt3.setText(o.getGiftName().get(i));
                }
                if (i==3){
                    txt4.setText(o.getGiftName().get(i));
                }
                System.out.println(o.getGiftName().get(i));
            }
        } catch (IOException | ClassNotFoundException ex) {
            System.out.println("Error wrting to file");
        }

        txt5.setText(DiNAme);

        txtTotl.setText(String.valueOf(DisP+giftTotl));
    }


    public void QuitAction(ActionEvent actionEvent) {
        System.exit(0);
    }
}
