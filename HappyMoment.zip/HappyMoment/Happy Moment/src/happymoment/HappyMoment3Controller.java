/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package happymoment;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author maram
 */
public class HappyMoment3Controller implements Initializable {

    @FXML
    private Button Choose;
    @FXML
    private RadioButton ID2;
    @FXML
    private RadioButton ID3;
    @FXML
    private RadioButton ID4;
    @FXML
    private RadioButton ID1;
    @FXML
    private ToggleGroup Price;
    @FXML
    private MenuItem Quit;
    
    String GN;
    double GP;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }


    @FXML
    private void ChooseAction(ActionEvent event) throws Exception {
        String DesignID = null;
        int DesignPrice = 0;

        // Next button TO CONNECT ANOTHER WINDOW (Design Window) 
        // 1. must be check the user added all input with method inputValidation()
                inputValidation();
        //2. send your choose to the order windowc
        try {
            //hide the current window
            ((Node) event.getSource()).getScene().getWindow().hide();

            //load (Design window)
            FXMLLoader loader = new FXMLLoader(getClass().getResource("HappyMoment4.fxml"));
            Parent root = loader.load();

            //create object of the order window controller
            HappyMoment4Controller controller4 = loader.getController();
            
            if (ID1.isSelected()) {
                DesignID = "Design ID 1";
                DesignPrice = 300;
            } else if (ID2.isSelected()) {
                DesignID = "Design ID 2";
                DesignPrice = 350;
            } else if (ID3.isSelected()) {
                DesignID = "Design ID 3";
                DesignPrice = 390;
            } else if (ID4.isSelected()) {
                DesignID = "Design ID 4";
                DesignPrice = 400;
            }

            controller4.setDesignData(DesignID, DesignPrice);
            controller4.setGiftData(GN, GP);
            //show the Design window
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.show();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

// method
    private void inputValidation() throws Exception {
// check if user choose your gift 
        if (!ID1.isSelected() && !ID2.isSelected() && !ID3.isSelected() && !ID4.isSelected()) {
            JOptionPane.showMessageDialog(null, "Select the Design!", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }

    }

    @FXML
    private void QuitAction(ActionEvent event) {
        
        System.exit(0);
    }

    void setGiftData(String GiftName, double GiftPrice) {
       GN= GiftName;
       GP= GiftPrice;
    
    }

}
