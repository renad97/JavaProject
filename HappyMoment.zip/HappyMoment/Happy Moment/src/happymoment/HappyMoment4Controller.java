/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package happymoment;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author maram
 */
public class HappyMoment4Controller implements Initializable {

    @FXML
    private Button Confirm;
    @FXML
    private Button Cancel;

    private final Orders order = HappyMoment2Controller.orders; //global object
    @FXML
    private TextField GiftName;
    @FXML
    private TextField DesignName;
    @FXML
    private TextField GiftPrice;
    @FXML
    private TextField DesignPrice;
    @FXML
    private MenuItem Quit;

    HappyMoment5 happy;

    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void ConfirmAction(ActionEvent event) {
        //Step1: write student information to the file
        writeToFile(order);

        //Step2: then go back to the gift window to add another gift
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("HappyMoment5.fxml"));
            Stage stage2 = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage2.setScene(scene);

            happy = loader.getController();

            happy.setOrder(Integer.parseInt(DesignPrice.getText()), Double.parseDouble(GiftPrice.getText()), DesignName.getText());

        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        } catch (Exception e) {
            System.out.println("Invalid input");
        }
    }

    @FXML
    private void CancelAction(ActionEvent event) {
        //go back to the first window
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("HappyMoment.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(loader.load());
            stage.setScene(scene);


        } catch (IOException io) {
            System.out.println("FXML Loading Error");
        }
    }

    public void setGiftData(String GiftName, double GiftPrice) {
        this.GiftName.setText(GiftName);
        this.GiftPrice.setText(String.valueOf(GiftPrice));



    }

    //get data from the Designs window
    public void setDesignData(String DesignID, int DesignPrice) {
        this.DesignName.setText(DesignID);
        this.DesignPrice.setText(String.valueOf(DesignPrice));


    }


// methof to write all order Details in file
    private void writeToFile(Orders o) {
        // Create the stream objects.
        ObjectOutputStream objectOutputFile = null;
        FileOutputStream outStream = null;
        try {
            outStream = new FileOutputStream("GiftOrders.dat");
            objectOutputFile = new ObjectOutputStream(outStream);
            // Write the serialized objects to the file.
            objectOutputFile.writeObject(o);
            //show confirmation message
            JOptionPane.showMessageDialog(null, "Gift Order is added successfully");
            objectOutputFile.close();

        } catch (FileNotFoundException ex) {
            System.out.println("Error wrting to file");
        } catch (IOException ex) {
            System.out.println("Error wrting to file");
        }

    }

    @FXML
    private void QuitAction(ActionEvent event) {

        System.exit(0);
    }
}
