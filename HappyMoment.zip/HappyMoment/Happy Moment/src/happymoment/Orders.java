/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package happymoment;

import java.io.Serializable;
import java.util.ArrayList;

/**
 *
 * @author maram
 */
public class Orders implements Serializable {

    public ArrayList<String> GiftName = new ArrayList<>();
    public ArrayList<Double> GiftPrice = new ArrayList<>();
    public String DesignId;
    public int DesignPrice;

    public Orders() {
    }

    public Orders(String GiftName, double GiftPrice) {
        this.GiftName.add(GiftName);
        this.GiftPrice.add(GiftPrice);
    }

    public Orders(String DesignId, int DesignPrice) {
        this.DesignId = DesignId;
        this.DesignPrice = DesignPrice;
    }

    public ArrayList<String> getGiftName() {
        return GiftName;
    }

    public void setGiftName(String GiftName) {
        this.GiftName.add(GiftName);
    }

    public int getDesignPrice() {
        return DesignPrice;
    }

    public void setDesignPrice(int designPrice) {
        DesignPrice = designPrice;
    }

    public ArrayList<Double> getGiftPrice() {
        return GiftPrice;
    }

    public void setGiftPrice(double GiftPrice) {
        this.GiftPrice.add(GiftPrice);
    }

    public String getDesignId() {
        return DesignId;
    }

    public void setDesignId(String DesignId) {
        this.DesignId = DesignId;
    }


    public void setGiftPrice(ArrayList<Double> giftPrice) {
        GiftPrice = giftPrice;
    }

}
