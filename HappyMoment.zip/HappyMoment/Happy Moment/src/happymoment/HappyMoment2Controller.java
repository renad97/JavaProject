/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package happymoment;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 * FXML Controller class
 *
 * @author maram
 */
public class HappyMoment2Controller implements Initializable {

    static Orders orders = new Orders();
    @FXML
    private Button Choose;
    @FXML
    private Text DknyNecklace;
    @FXML
    private Text ToryBorchNecklace;
    @FXML
    private Text ChNecklace;
    @FXML
    private Text AirPods;
    @FXML
    private CheckBox GF1;
    @FXML
    private ToggleGroup Price;
    @FXML
    private CheckBox GF2;
    @FXML
    private CheckBox GF3;
    @FXML
    private CheckBox GF4;
    @FXML
    private MenuItem Quit;
    private int pric =0;

    private String g1;
    private String g2;
    private String g3;
    private String g4;
    
    String GiftName = null;
        double GiftPrice = 0;
    
  //  HappyMoment4Controller Controller4; 

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    @FXML
    private void ChooseAction(ActionEvent event) throws Exception {
        

        // Next button TO CONNECT ANOTHER WINDOW (Design Window) 
        // 1. must be check the user added all input with method inputValidation()
       
        inputValidation();
        
        //hide the current window
            ((Node) event.getSource()).getScene().getWindow().hide();

            //load (Design window)
            FXMLLoader loader1 = new FXMLLoader(getClass().getResource("HappyMoment3.fxml"));
            Parent root = loader1.load();

            //create object of the order window controller
            HappyMoment3Controller controller3 = loader1.getController();

        //2. send your choose to the order windows
        if (GF1.isSelected()) {
            GiftName = "Air Pods";
            GiftPrice = 1090;
            pric+=GiftPrice;
            orders.setGiftName(GiftName);

        }
        if (GF2.isSelected()) {
            GiftName = "DKNY Neclace";
            GiftPrice = 500;
            pric+=GiftPrice;

            orders.setGiftName(GiftName);
        }
        if (GF3.isSelected()) {
            GiftName = "Tory Burch Neclace";
            GiftPrice = 400;
            pric+=GiftPrice;

            orders.setGiftName(GiftName);
        }
        if (GF4.isSelected()) {
            GiftName = "CH Neclace";
            GiftPrice = 670;
            pric+=GiftPrice;

            orders.setGiftName(GiftName);
        }

        controller3.setGiftData(GiftName, pric);
        //save a data
        //  HappyMoment4Controller HB4 = new HappyMoment4Controller ();

        //show the design window
        //      FXMLLoader loader1 = new FXMLLoader(getClass().getResource("HappyMoment3.fxml"));
        Stage stage = new Stage();
        stage.setScene(new Scene(root));
        stage.show();
    }

// method
    private void inputValidation() throws Exception {
// check if user choose your gift 
        if (!GF1.isSelected() && !GF2.isSelected() && !GF3.isSelected() && !GF4.isSelected()) {
            JOptionPane.showMessageDialog(null, "Select the Gift!", "Error", JOptionPane.ERROR_MESSAGE);
            throw new Exception();
        }
    }
    
     //get data from the Gifts window


    @FXML
    private void QuitAction(ActionEvent event) {
        System.exit(0);
    }








    
}
